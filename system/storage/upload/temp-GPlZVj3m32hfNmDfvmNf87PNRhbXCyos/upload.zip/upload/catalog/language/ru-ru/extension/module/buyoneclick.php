<?php
$_['buyoneclick_title'] = 'Быстрый заказ';
$_['buyoneclick_button'] = 'Купить быстро';
$_['buyoneclick_field1_title'] = 'Имя';
$_['buyoneclick_field2_title'] = 'Телефон';
$_['buyoneclick_field3_title'] = 'E-mail';
$_['buyoneclick_field4_title'] = 'Сообщение';
$_['buyoneclick_button_order'] = 'Отправить';
$_['buyoneclick_required_text'] = 'обязательное поле';
$_['buyoneclick_success'] = '<h4>Спасибо за Ваш заказ!<br />Мы свяжемся с Вами в самое ближайшее время.</h4>';
$_['buyoneclick_error_required'] = 'Пожалуйста, заполните обязательные поля!';
$_['buyoneclick_error_sending'] = 'Ошибка отправки, пожалуйста, попробуйте повторить позднее!';
$_['buyoneclick_text_agree'] = 'Я прочитал(а) и согласен(на) с  <a href="%s" class="agree"><b>%s</b></a>';